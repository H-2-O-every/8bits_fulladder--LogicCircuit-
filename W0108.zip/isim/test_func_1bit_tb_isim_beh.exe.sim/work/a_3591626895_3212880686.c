/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_2592010699;
static const char *ng1 = "D:/vhdl2019w/YYI2015117185/W0108/test_func_1bit_mod.vhd";

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


unsigned char work_a_3591626895_3212880686_sub_3239464599_3057020925(char *t1, unsigned char t2, unsigned char t3, unsigned char t4)
{
    char t6[8];
    unsigned char t0;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;

LAB0:    t7 = (t6 + 4U);
    *((unsigned char *)t7) = t2;
    t8 = (t6 + 5U);
    *((unsigned char *)t8) = t3;
    t9 = (t6 + 6U);
    *((unsigned char *)t9) = t4;
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t2, t3);
    t11 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t10, t4);
    t0 = t11;

LAB1:    return t0;
LAB2:;
}

unsigned char work_a_3591626895_3212880686_sub_3777476451_3057020925(char *t1, unsigned char t2, unsigned char t3, unsigned char t4)
{
    char t6[8];
    unsigned char t0;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;

LAB0:    t7 = (t6 + 4U);
    *((unsigned char *)t7) = t2;
    t8 = (t6 + 5U);
    *((unsigned char *)t8) = t3;
    t9 = (t6 + 6U);
    *((unsigned char *)t9) = t4;
    t10 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t2, t3);
    t11 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t4);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t10, t11);
    t13 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t2);
    t14 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t12, t13);
    t0 = t14;

LAB1:    return t0;
LAB2:;
}

static void work_a_3591626895_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(49, ng1);

LAB3:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 684U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t1 = (t0 + 776U);
    t6 = *((char **)t1);
    t7 = *((unsigned char *)t6);
    t8 = work_a_3591626895_3212880686_sub_3239464599_3057020925(t0, t3, t5, t7);
    t1 = (t0 + 2012);
    t9 = (t1 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t8;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t13 = (t0 + 1960);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3591626895_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(50, ng1);

LAB3:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 684U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t1 = (t0 + 776U);
    t6 = *((char **)t1);
    t7 = *((unsigned char *)t6);
    t8 = work_a_3591626895_3212880686_sub_3777476451_3057020925(t0, t3, t5, t7);
    t1 = (t0 + 2048);
    t9 = (t1 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t8;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t13 = (t0 + 1968);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_3591626895_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3591626895_3212880686_p_0,(void *)work_a_3591626895_3212880686_p_1};
	static char *se[] = {(void *)work_a_3591626895_3212880686_sub_3239464599_3057020925,(void *)work_a_3591626895_3212880686_sub_3777476451_3057020925};
	xsi_register_didat("work_a_3591626895_3212880686", "isim/test_func_1bit_tb_isim_beh.exe.sim/work/a_3591626895_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
